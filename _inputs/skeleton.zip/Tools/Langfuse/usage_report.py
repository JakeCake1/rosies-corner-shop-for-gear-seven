#!/usr/bin/env python3
"""Measures the AI agent's resource consumption per task phase and exports it for Langfuse.

The agent session writes one JSONL transcript per session (plus one per subagent). Every model
reply carries token usage. This script:

  mark <phase>      appends a phase boundary (UTC now) to phases.json; the previous phase ends there.
  report            aggregates usage per phase and writes usage_summary.json, REPORT.md and
                    langfuse_batch.json (Langfuse public ingestion API format).

Send the batch with Send-ToLangfuse.ps1 (Windows) or send_to_langfuse.py (any OS with network access).

Effective cost weights (relative to one uncached input token) follow Anthropic's pricing ratios:
cache read 0.1x, cache write (1h TTL) 2x, output 5x.
"""
import argparse
import datetime as dt
import glob
import json
import os
import sys
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
PHASES_FILE = os.path.join(HERE, "phases.json")
WEIGHTS = {"input": 1.0, "cache_read": 0.1, "cache_write": 2.0, "output": 5.0}
TRACE_NAMESPACE = uuid.UUID("6f0d7c1e-0b7a-4c8e-9a51-7a2f3c9e1d42")


def utc_now():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def parse_ts(value):
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


def load_phases():
    if not os.path.exists(PHASES_FILE):
        return {"task": "", "issue": "", "transcriptGlob": "", "phases": []}
    with open(PHASES_FILE, encoding="utf-8") as f:
        return json.load(f)


def save_phases(data):
    with open(PHASES_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def cmd_mark(args):
    data = load_phases()
    now = args.at or utc_now()
    if data["phases"] and not data["phases"][-1].get("end"):
        data["phases"][-1]["end"] = now
    if args.phase != "-":
        data["phases"].append({"name": args.phase, "start": now, "end": None})
    save_phases(data)
    print(f"marked '{args.phase}' at {now}")


def read_messages(paths):
    """Returns one record per API reply (deduplicated by message id; the last entry holds final usage)."""
    by_id = {}
    for path in paths:
        agent = "main" if os.path.basename(os.path.dirname(path)) == "projects" or "/subagents/" not in path else "subagent"
        source = os.path.splitext(os.path.basename(path))[0]
        with open(path, encoding="utf-8") as f:
            for line in f:
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if entry.get("type") != "assistant":
                    continue
                msg = entry.get("message") or {}
                usage = msg.get("usage")
                mid = msg.get("id")
                if not usage or not mid or msg.get("model") == "<synthetic>":
                    continue
                rec = by_id.setdefault(mid, {"id": mid, "tools": [], "agent": agent, "source": source})
                rec.update(timestamp=entry["timestamp"], model=msg.get("model"), usage=usage)
                for block in msg.get("content") or []:
                    if isinstance(block, dict) and block.get("type") == "tool_use":
                        rec["tools"].append(block.get("name"))
    return sorted(by_id.values(), key=lambda r: r["timestamp"])


def usage_numbers(u):
    cw = u.get("cache_creation_input_tokens") or 0
    out = {
        "input": u.get("input_tokens") or 0,
        "output": u.get("output_tokens") or 0,
        "cache_read": u.get("cache_read_input_tokens") or 0,
        "cache_write": cw,
        "thinking": (u.get("output_tokens_details") or {}).get("thinking_tokens") or 0,
        "web_search": (u.get("server_tool_use") or {}).get("web_search_requests") or 0,
        "web_fetch": (u.get("server_tool_use") or {}).get("web_fetch_requests") or 0,
    }
    out["effective"] = sum(out[k] * w for k, w in WEIGHTS.items())
    return out


def phase_of(ts, phases):
    t = parse_ts(ts)
    for p in phases:
        start = parse_ts(p["start"])
        end = parse_ts(p["end"]) if p.get("end") else None
        if t >= start and (end is None or t < end):
            return p["name"]
    return "(unassigned)"


def tool_group(name):
    if not name:
        return "other"
    if name.startswith("mcp__"):
        parts = name.split("__")
        return "mcp:" + (parts[1] if len(parts) > 1 else name)
    return name


def cmd_report(args):
    data = load_phases()
    pattern = args.transcripts or data.get("transcriptGlob")
    paths = sorted(set(glob.glob(os.path.expanduser(pattern), recursive=True)))
    if not paths:
        sys.exit(f"no transcripts match {pattern!r}")
    msgs = read_messages(paths)
    phases = data["phases"]
    keys = ["input", "output", "cache_read", "cache_write", "thinking", "web_search", "web_fetch", "effective"]

    summary = {"task": data.get("task"), "issue": data.get("issue"), "generatedAt": utc_now(),
               "weights": WEIGHTS, "transcripts": len(paths), "replies": len(msgs), "phases": [], "total": {}}
    total = {k: 0 for k in keys}
    per_phase = {}
    for m in msgs:
        name = phase_of(m["timestamp"], phases)
        m["phase"] = name
        n = usage_numbers(m["usage"])
        p = per_phase.setdefault(name, {"replies": 0, "tools": {}, "models": {}, **{k: 0 for k in keys},
                                        "first": m["timestamp"], "last": m["timestamp"]})
        p["replies"] += 1
        p["last"] = m["timestamp"]
        p["models"][m["model"]] = p["models"].get(m["model"], 0) + 1
        for t in m["tools"]:
            g = tool_group(t)
            p["tools"][g] = p["tools"].get(g, 0) + 1
        for k in keys:
            p[k] += n[k]
            total[k] += n[k]

    order = [p["name"] for p in phases] + [k for k in per_phase if k not in {p["name"] for p in phases}]
    for name in order:
        if name not in per_phase:
            continue
        p = per_phase[name]
        ph = next((x for x in phases if x["name"] == name), {})
        start = ph.get("start") or p["first"]
        end = ph.get("end") or p["last"]
        p.update(name=name, start=start, end=end,
                 wallMinutes=round((parse_ts(end) - parse_ts(start)).total_seconds() / 60, 1),
                 effective=round(p["effective"]))
        summary["phases"].append(p)
    total["effective"] = round(total["effective"])
    summary["total"] = total

    out_dir = args.out or HERE
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "usage_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    with open(os.path.join(out_dir, "langfuse_batch.json"), "w", encoding="utf-8") as f:
        json.dump(build_batch(summary, msgs, data), f, indent=1)
    with open(os.path.join(out_dir, "REPORT.md"), "w", encoding="utf-8") as f:
        f.write(build_markdown(summary))
    print(f"{len(msgs)} replies from {len(paths)} transcript(s); effective tokens {total['effective']:,}")


def build_batch(summary, msgs, data):
    """Langfuse ingestion events: one trace for the task, one span per phase, one generation per reply."""
    trace_id = str(uuid.uuid5(TRACE_NAMESPACE, (data.get("issue") or "task") + "|" + (data.get("task") or "")))
    now = utc_now()
    events = [{
        "id": str(uuid.uuid4()), "timestamp": now, "type": "trace-create",
        "body": {"id": trace_id, "name": f"{data.get('issue')} {data.get('task')}".strip(),
                 "timestamp": summary["phases"][0]["start"] if summary["phases"] else now,
                 "tags": ["claude-agent", "resource-consumption", data.get("issue") or "task"],
                 "metadata": {"weights": WEIGHTS, "replies": summary["replies"]},
                 "output": {"total": summary["total"]}},
    }]
    span_ids = {}
    for p in summary["phases"]:
        sid = str(uuid.uuid5(TRACE_NAMESPACE, trace_id + "|phase|" + p["name"]))
        span_ids[p["name"]] = sid
        events.append({
            "id": str(uuid.uuid4()), "timestamp": now, "type": "span-create",
            "body": {"id": sid, "traceId": trace_id, "name": p["name"], "startTime": p["start"],
                     "endTime": p["end"],
                     "metadata": {k: p[k] for k in ("replies", "tools", "models", "wallMinutes", "effective",
                                                    "input", "output", "cache_read", "cache_write", "thinking")}},
        })
    prev_end = {}
    for m in msgs:
        n = usage_numbers(m["usage"])
        parent = span_ids.get(m["phase"])
        start = prev_end.get(m["source"], m["timestamp"])
        prev_end[m["source"]] = m["timestamp"]
        events.append({
            "id": str(uuid.uuid4()), "timestamp": now, "type": "generation-create",
            "body": {"id": str(uuid.uuid5(TRACE_NAMESPACE, m["id"])), "traceId": trace_id,
                     "parentObservationId": parent, "name": "agent-turn" if m["agent"] == "main" else "subagent-turn",
                     "model": m["model"], "startTime": start, "endTime": m["timestamp"],
                     "usageDetails": {"input": n["input"], "output": n["output"],
                                      "cache_read_input_tokens": n["cache_read"],
                                      "cache_creation_input_tokens": n["cache_write"]},
                     "metadata": {"tools": m["tools"], "thinking_tokens": n["thinking"],
                                  "effective_tokens": round(n["effective"], 1), "phase": m["phase"]}},
        })
    return {"batch": events}


def build_markdown(s):
    fmt = "{:,}".format
    lines = [f"# Resource consumption: {s['issue']} {s['task']}", "",
             f"Generated {s['generatedAt']} from {s['transcripts']} transcript(s), {s['replies']} model replies.", "",
             "Effective tokens weight each kind by its price relative to an uncached input token: "
             "cache read 0.1x, cache write 2x, output 5x.", "",
             "| Phase | Wall time, min | Replies | Output | Cache read | Cache write | Effective | Share |",
             "|---|---:|---:|---:|---:|---:|---:|---:|"]
    tot = s["total"]["effective"] or 1
    for p in s["phases"]:
        lines.append(f"| {p['name']} | {p['wallMinutes']} | {p['replies']} | {fmt(p['output'])} | "
                     f"{fmt(p['cache_read'])} | {fmt(p['cache_write'])} | {fmt(p['effective'])} | "
                     f"{p['effective'] * 100 // tot}% |")
    t = s["total"]
    lines += [f"| **Total** | | {s['replies']} | {fmt(t['output'])} | {fmt(t['cache_read'])} | "
              f"{fmt(t['cache_write'])} | {fmt(t['effective'])} | 100% |", "", "## Tool calls per phase", ""]
    for p in s["phases"]:
        top = sorted(p["tools"].items(), key=lambda kv: -kv[1])
        lines.append(f"- **{p['name']}**: " + (", ".join(f"{k} ×{v}" for k, v in top) or "none"))
    lines.append("")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("mark")
    m.add_argument("phase", help="phase name, or '-' to close the current phase")
    m.add_argument("--at", help="ISO UTC timestamp instead of now")
    m.set_defaults(func=cmd_mark)
    r = sub.add_parser("report")
    r.add_argument("--transcripts", help="glob of transcript JSONL files (defaults to phases.json transcriptGlob)")
    r.add_argument("--out", help="output folder (default: this folder)")
    r.set_defaults(func=cmd_report)
    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
